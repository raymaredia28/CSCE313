/*
	Author of the starter code
    Yifan Ren
    Department of Computer Science & Engineering
    Texas A&M University
    Date: 9/15/2024
	
	Please include your Name, UIN, and the date below
	Name:
	UIN:
	Date:
*/
#include "common.h"
#include "FIFORequestChannel.h"

using namespace std;


int main (int argc, char *argv[]) {
	int opt;
	int p = -1;
	double t = -1;
	int e = -1;
	string filename = "";
	int m = MAX_MESSAGE;
	bool new_chan = false;
	vector<FIFORequestChannel*>channels;
	//Add other arguments here
	while ((opt = getopt(argc, argv, "p:t:e:f:m:c")) != -1) {
		switch (opt) {
			case 'p':
				p = atoi (optarg);
				break;
			case 't':
				t = atof (optarg);
				break;
			case 'e':
				e = atoi (optarg);
				break;
			case 'f':
				filename = optarg;
				break;
			case 'm':
				m = atoi(optarg);
				break;
			case 'c':
				new_chan = true;
				break;
		}
	}

	//specify/give arguments to the server
	//server needs , './server', '-m' arg, value for -m, "NULL"
	//fork
	//In the child, run execvp using the server args
	//
	//Task 1:
	//Run the server process as a child of the client process
	string message_m = to_string(m);
	char* m_param = new char[message_m.size() + 1];
	strcpy(m_param, message_m.c_str());
	char* arg[] = {(char*)"./server", (char*)"-m", m_param, NULL};
	pid_t child = fork();
	if(child == 0){
		execvp(arg[0], arg);
		perror("Failed execvp");
		exit(1);

	}
	else if (child < 0){
		perror("Child failure");
		delete [] m_param;
		exit(1);
	}
	delete [] m_param;
    FIFORequestChannel cont_chan("control", FIFORequestChannel::CLIENT_SIDE);
	
	//Task 4:
	//Request a new channel
	channels.push_back(&cont_chan);

	if(new_chan){
		MESSAGE_TYPE nc = NEWCHANNEL_MSG;
		cont_chan.cwrite(&nc, sizeof(MESSAGE_TYPE));
		//make a var to hold the name
		//cread response from the server
		//call fiforequestchannel constructor with the name from the server
		char new_chan_name[100];	
		cont_chan.cread(new_chan_name, sizeof(new_chan_name));
		FIFORequestChannel* newchannel = new FIFORequestChannel(new_chan_name, FIFORequestChannel::CLIENT_SIDE);
		channels.push_back(newchannel);
	}
	FIFORequestChannel chan = *(channels.back());
	//Task 2:
	//Request data points
	//Single datapoint, only run P, t, e != -1
	if(p != -1 && t != -1 && e != -1){
		char buf[MAX_MESSAGE]; //256
		datamsg x(p, t, e); //change from hardcoding to user's values
		
		memcpy(buf, &x, sizeof(datamsg));
		chan.cwrite(buf, sizeof(datamsg));
		double reply;
		chan.cread(&reply, sizeof(double));
		cout << "For person " << p << ", at time " << t << ", the value of ecg " << e << " is " << reply << endl;
	}
	
	
	//else, if p != -1, request 1000 data points
	//loop over 1st 1000 lines
	//send request for ecg 1
	//send request for ecg 2
	//write line to received/x1.csv (file location)
	else if(p != -1){
		ofstream file_writer("received/x1.csv");
		if(!file_writer){
			cerr << "File open error";
			exit(1);
		}
		char buffer[MAX_MESSAGE];
		double time = 0.004;
		double ecg1, ecg2;
		for(int i = 0; i < 1000; i++){
			double c_time = i * time;
			
			datamsg ECG1(p, c_time, 1);
			memcpy(buffer, &ECG1, sizeof(datamsg));
			chan.cwrite(buffer, sizeof(datamsg));
			chan.cread(&ecg1, sizeof(double));

			datamsg ECG2(p, c_time, 2);
			memcpy(buffer, &ECG2, sizeof(datamsg));
			chan.cwrite(buffer, sizeof(datamsg));
			chan.cread(&ecg2, sizeof(double));

			file_writer << c_time << ","  << ecg1 << "," << ecg2 << endl;
		}
		file_writer.close();
	}
	//Task 3:
	//Request files
	filemsg fm(0, 0);
	string fname = filename;
	//buffcap - how many bytes to send -> file lenght is large so we need to split it up
	
	//filemsg - t, offset, len
	//filename 8.csv
	//buffer request -> file message size + file name 
	//buffer response -> size buffer capacity

	int len = sizeof(filemsg) + (fname.size() + 1);
	char* buf2 = new char[len];
	memcpy(buf2, &fm, sizeof(filemsg));
	strcpy(buf2 + sizeof(filemsg), fname.c_str());
	chan.cwrite(buf2, len);

	
	
	
	__int64_t file_length;
	chan.cread(&file_length, sizeof(__int64_t));
	char* buf3 = new char[m];//creat buffer of size capacity(n)
	ofstream output_file("received/" + fname, ios::binary);
	if(!output_file){
		cerr << "file open error";
		delete[] buf2;
		delete[] buf3;
		exit(1);
	}
	cout << "The length of " << fname << " is " << file_length << endl;
	__int64_t gap = 0;
	//loop over semengs int the file filesize/buff capacity (m)
	//create file msg instance
	while(gap < file_length){
		filemsg* file_req = (filemsg*)buf2;
		file_req->offset = gap ; //set offset in file
		file_req->length = min((__int64_t)m, file_length - gap);//set the length, careful of lat segment
		chan.cwrite(buf2, len); //send the request(buf2)
		chan.cread(buf3, file_req->length); //load into buf3
		output_file.write(buf3, file_req->length); //write values of buf3 into the output file
		gap += file_req->length; //update size of message gap to move onto the next section
	}
	
	delete[] buf2;
	delete[] buf3;

	output_file.close();
	
	//close and delete new channel
	if(new_chan){
		FIFORequestChannel* newchannel = channels.back();
		MESSAGE_TYPE quit = QUIT_MSG;
		newchannel->cwrite(&quit, sizeof(MESSAGE_TYPE));
		delete newchannel;
		channels.pop_back();
	}
	//Task 5:
	// Closing all the channels
    MESSAGE_TYPE mm = QUIT_MSG;
    chan.cwrite(&mm, sizeof(MESSAGE_TYPE));
}
