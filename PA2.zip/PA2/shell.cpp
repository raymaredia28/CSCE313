/*
    Programming Assignment 2: Aggie Shell

    ==================================================
    Original assignment code written and provided by:
        Professor Kumar
        Department of Computer Science and Engineering
        Texas A&M University
        Date: 10/10/2024
    ==================================================

    ==================================================
    Pseudo-code and commented edits authored by:
        Kyle Lang
        Department of Computer Science and Engineering
        Texas A&M University
        Date: 10/10/2024
    ==================================================
*/

#include <iostream>

#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
#include <termios.h>


#include <vector>
#include <string>
#include <ctime>

#include "Tokenizer.h"

// all the basic colors for a shell prompt
#define RED     "\033[1;31m"
#define GREEN   "\033[1;32m"
#define YELLOW  "\033[1;33m"
#define BLUE    "\033[1;34m"
#define WHITE   "\033[1;37m"
#define NC      "\033[0m"
#define PATH_MAX 500

using namespace std;

/**
 * Return Shell prompt to display before every command as a string
 * 
 * Prompt format is: `{MMM DD hh:mm:ss} {user}:{current_working_directory}$`
 */
void print_prompt() {
   //Getting system and local time
        time_t curr_time;
        time(&curr_time);
        tm* local_time = localtime(&curr_time);
        
        //getting the format of the date into a string
        char time_string[16];
        strftime(time_string, sizeof(time_string), "%b %d %H:%M:%S", local_time);
        
        // Obtain current user and current working directory by calling getenv()
        // and obtaining the "USER" and "PWD" environment variables
        char* curr_user = getenv("USER");
        char* curr_pwd = getenv("PWD");

        // Can use colored #define's to change output color by inserting into output stream
        // MODIFY to output a prompt format that has at least the USER and CURRENT WORKING DIRECTORY
        cout << YELLOW << "shell" << NC << "{" << time_string << "} {" << curr_user << "@" << curr_pwd << "}$";
}

/**
 * Process shell commands line-by-line and execute them, handling pipes and redirection.
 */
vector<pid_t> bg_children; //store background child processes
void process_commands(Tokenizer& tknr) {
    // Declare file descriptor variables for storing unnamed pipe fd's
    // Maintain both a FORWARD and BACKWARDS pipe in the parent for command redirection
    int backwards_fds[2] = {-1, -1}; //-1 makes it so that it takes no input in
    int forwards_fds[2] = {-1, -1}; 

    // LOOP THROUGH COMMANDS FROM SHELL INPUT
    for (auto& cmd: tknr.commands) {
        // Check if the command is 'cd' first
        // This will not have any pipe logic and needs to be done manually since 'cd' is not an executable command
        // Use getenv(), setenv(), and chdir() here to implement this command
        if (cmd->args[0] == "cd") {
            // There are two tested inputs for 'cd':
            // (1) User provides "cd -", which directs to the previous directory that was opened
            
            
            if (cmd->args[1] == "-") {
                const char* prev_dir = getenv("OLDPWD"); //prev directory
                const char* curr_dir = getenv("PWD");
                if (chdir(prev_dir) == 0) { //error checking, this function could fail
                    setenv("OLDPWD", curr_dir, 1);
                    char new_cwd[PATH_MAX];//set PWD to cwd path for further execution
                    getcwd(new_cwd, sizeof(new_cwd));
                    setenv("PWD", new_cwd, 1);
                } 
                else {
                    perror("chdir error");
                }

            } 
            // (2) User provides a directory to open
            else { 
                const char* next_dir = cmd->args[1].c_str(); //extra steps for next directory
                const char* curr_dir = getenv("PWD");
                if (chdir(next_dir) == 0) {
                    setenv("OLDPWD", curr_dir, 1);
                    char new_cwd[PATH_MAX];//set PWD to cwd path for further execution
                    getcwd(new_cwd, sizeof(new_cwd));
                    setenv("PWD", new_cwd, 1);
                } 
                else {
                    perror("chdir error");
                }
            }

            
            continue;
        }
        // Initialize backwards pipe to forward pipe
        backwards_fds[0] = forwards_fds[0];
        backwards_fds[1] = forwards_fds[1];
        
        // If any other command, set up forward pipe IF the current command is not the last command to be executed
        if (cmd != tknr.commands.back()) {
            if (pipe(forwards_fds) == -1) {
                perror("pipe error");
                exit(1);
            }
        }

        //fork to create child
        pid_t pid = fork();
        if (pid < 0) { //error check
            perror("fork error");
            exit(2);
        }

        if (pid == 0) { // if child, exec to run command

            if (cmd != tknr.commands.back()) {  // i.e. {current command} | {next command} ...
                dup2(forwards_fds[1], STDOUT_FILENO); // Reidrect STDOUT to forward pipe
                close(forwards_fds[0]); // Close respective pipe end
                close(forwards_fds[1]);
            }

            if (cmd != tknr.commands.front()) { // i.e. {first command} | {current command} ...
                dup2(backwards_fds[0], STDIN_FILENO); // Redirect STDIN to backward pipe
                close(backwards_fds[0]); // Close respective pipe end
                close(backwards_fds[1]);
            }

            if (cmd->hasInput()) {  // i.e. {command} < {input file}
                int fd_in = open(cmd->in_file.c_str(), O_RDONLY); // Open input file
                if (fd_in == -1) {//error handling issues
                    perror("Input file open failure");
                    exit(1);
                }
                dup2(fd_in, STDIN_FILENO); // Redirect STDIN from file

                close(fd_in);
            }

            if (cmd->hasOutput()) { // i.e. {command} > {output file}
                int fd_out = open(cmd->out_file.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0644);
                if (fd_out == -1) {
                    perror("Open output file failure");
                    exit(1);
                }
                dup2(fd_out, STDOUT_FILENO);
                close(fd_out);
            }

            vector<char*> args;
            for (const string& arg : cmd->args) {
                args.push_back(const_cast<char*>(arg.c_str()));
            }
            args.push_back(nullptr); //needed for execvp ordering

            if(execvp(args[0], args.data()) < 0){ //takes in arrays
                perror("execvp");
                exit(2);
            }
        } 
        else {     // if parent, wait for child to finish   
            // Close pipes from parent so pipes receive `EOF`
            // Pipes will otherwise get stuck indefinitely waiting for parent input/output that will never occur
            close(backwards_fds[0]);
            close(backwards_fds[1]);

           // If command is indicated as a background process, set up to ignore child signal to prevent zombie processes
            if (cmd->isBackground()) {
                signal(SIGCHLD, SIG_IGN);
                bg_children.push_back(pid); 
            }
            else{//if not background free child
                int status = 0; 
                waitpid(pid, &status, 0);
                if(status > 1){
                    exit(status);
                }
            }
        }
    }

}


int main() {
    // Use setenv() and getenv() to set an environment variable for the previous PWD from 'PWD'
    if (getenv("OLDPWD") == nullptr) { //if the previous pwd was null then set it to curr
        setenv("OLDPWD", getenv("PWD"), 1); //normal one should already be set
    }

    // This is your process loop; Will run infinitely until given defined break case
    for (;;) {
        // need to print date/time, username, and absolute path to current dir into 'shell'
        // Might want to use a helper function like this here for code clarity
        print_prompt();
                
        // get user inputted command
        string input;
        getline(cin, input);
        
        if (input == "exit") {  // print exit message and break out of infinite loop
            cout << RED << "Now exiting shell..." << endl << "Goodbye" << NC << endl;
            break;
        }
        // Might want to catch empty input; Tokenizer will error and not recover on empty input

        // get tokenized commands from user input
        // This will parse your user input for you; Please refer the header files to understand how to use this class
        Tokenizer tknr(input);
        if (tknr.hasError()) {  // continue to next prompt if input had an error
            continue;
        }


        /*
        // print out every command token-by-token on individual lines
        // prints to cerr to avoid influencing autograder
        for (auto cmd : tknr.commands) {
            for (auto str : cmd->args) {
                cerr << "|" << str << "| ";
            }

            if (cmd->hasInput()) {
                cerr << "in< " << cmd->in_file << " ";
            }

            if (cmd->hasOutput()) {
                cerr << "out> " << cmd->out_file << " ";
            }
            cerr << endl;
        }
        */
       
        // Might want to use a helper function like this for processing the shell's command line 
        process_commands(tknr);
    }

    for (pid_t bg : bg_children) { //This loop will clear background children
                int status;
                waitpid(bg, &status, 0);
            }
    
}
