#include <threading.h>
int i;
void t_init()
{
        // TODO
        memset(contexts, 0, sizeof(contexts));
        for(i =0; i < NUM_CTX; i++){
                if(i == 0){
                        contexts[i].state = VALID;
                }
                else{
                        contexts[i].state = INVALID;
                }
        }
        current_context_idx = 0;
}

/**
 * This function takes in a lambda function and the arguments to be passed to
 * the lambda. It then creates a context out of these two pieces of data and
 * stores it in the contexts list
 *
 * param foo: A function pointer of the type fptr to the lambda
 * param arg1: The first argument to be passed to foo
 * param arg2: The second argument to be passed to foo
 * returns: 0 if successful, 1 otherwise
 */
int32_t t_create(fptr foo, int32_t arg1, int32_t arg2)
{     
        // TODO
        for(i = 0; i < NUM_CTX; i++){
                if(contexts[i].state == INVALID){
                        void *stack = malloc(STK_SZ);
                        if(stack == NULL){
                                return 1;
                        }

                        getcontext(&contexts[i].context);

                        contexts[i].context.uc_stack.ss_sp = stack;
                        contexts[i].context.uc_stack.ss_size = STK_SZ;
                        contexts[i].context.uc_link = NULL;
                        contexts[i].context.uc_stack.ss_flags = 0;
                        makecontext(&contexts[i].context,(void(*)())foo, 2, arg1, arg2);
                       
                       contexts[i].state = VALID;

                        return 0;
                }
        }
        return 1;
}

/**
 * This function cooperatively yields the control over to other workers. This
 * function may or may not return in the caller
 *
 * returns: This function returns the number of contexts (apart from the
 *          caller) which are in the VALID state if it is successful, otherwise
 *          it returns -1
 */
int32_t t_yield()
{
        // TODO
        if(getcontext(&contexts[current_context_idx].context) == -1){
                return -1; //if getting the current context fails
        }
        int valid = 0; //tracks if a valid context is found
        uint8_t saved_ind = 0;
        for(uint8_t i = 0; i < NUM_CTX; i++){
                if(contexts[i].state == VALID && i != current_context_idx){
                        valid = 1;
                        saved_ind = i; //Swap with this context
                        break;
                }      
        }
        if (!valid){
                return -1;
        }

        int prev = current_context_idx;
        current_context_idx = saved_ind;

        if(swapcontext(&contexts[prev].context, &contexts[current_context_idx].context) == -1){
                return -1; //if the act of swapping fails
        }
        int num_VALID = 0;
        for(int i = 0; i < NUM_CTX; i++){
                if(contexts[i].state == VALID && i != current_context_idx){
                        num_VALID++;
                }
        }
        return num_VALID;
}

/**
 * This function is called by the worker to indicate that it has completed its
 * work. After this function is called, the worker's context is deleted and the
 * worker is never scheduled back again 
 */
void t_finish()
{
        // TODO
        free(contexts[current_context_idx].context.uc_stack.ss_sp);
        contexts[current_context_idx].state = DONE;
        for(uint8_t i = 0; i < NUM_CTX; i++){
                if(contexts[i].state == VALID){
                        current_context_idx = i;
                        setcontext(&contexts[i].context);
                }
        }
}
