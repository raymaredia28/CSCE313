#include <Command.h>
#include <Tokenizer.h>
#include <ctime>
#include <fcntl.h>
#include <iostream>
#include <string.h>
#include <string>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <vector>

// all the basic colours for a shell prompt
#define RED    "\033[1;31m"
#define GREEN  "\033[1;32m"
#define YELLOW "\033[1;33m"
#define BLUE   "\033[1;34m"
#define WHITE  "\033[1;37m"
#define NC     "\033[0m"
using namespace std;

void print_prompt(){
        //Getting system and local time
        time_t curr_time;
        time(&curr_time);
        tm* local_time = localtime(&curr_time);
        
        //getting the format of the date into a string
        char time_string[16];
        strftime(time_string, sizeof(time_string), "%b %d %H:%M:%S", local_time);
        
        // Obtain current user and current working directory by calling getenv()
        // and obtaining the "USER" and "PWD" environment variables
        char* curr_user = getenv("USER");
        char* curr_pwd = getenv("PWD");

        // Can use colored #define's to change output color by inserting into output stream
        // MODIFY to output a prompt format that has at least the USER and CURRENT WORKING DIRECTORY
        cout << YELLOW << "shell" << NC << "{" << time_string << "} {" << curr_user << "@" << curr_pwd << "}$";

}

void process_commands(){
        //Pipes for unnamed pipe fd's
        int backwards_fds[2];
        int forwards_fds[2];

        

}
int main()
{
        for(;;) //infinite for-loop
        {
                // need date/time, username, and absolute path to current dir
                std::cout << YELLOW << "shell" << NC << " ";

                // get user inputted command
                std::string input;
                getline(std::cin, input);

                if(input == "exit")
                {
                        // print exit message and break out of infinite loop
                        std::cout << RED << "Now exiting shell..." << std::endl << "Goodbye" << NC << std::endl;
                        break;
                }

                // get tokenized commands from user input
                Tokenizer tknr(input);
                if(tknr.hasError())
                {
                        // continue to next prompt if input had an error
                        continue;
                }
                // // print out every command token-by-token on individual lines
                // // prints to cerr to avoid influencing autograder
                // for (auto cmd : tknr.commands) {
                //     for (auto str : cmd->args) {
                //         cerr << "|" << str << "| ";
                //     }
                //     if (cmd->hasInput()) {
                //         cerr << "in< " << cmd->in_file << " ";
                //     }
                //     if (cmd->hasOutput()) {
                //         cerr << "out> " << cmd->out_file << " ";
                //     }
                //     cerr << endl;
                // }

                // fork to create child
                pid_t pid = fork();
                if(pid < 0)
                { // error check
                        perror("fork");
                        exit(2);
                }

                if(pid == 0)
                { // if child, exec to run command
                        // run single commands with no arguments
                        char* args[] = {(char*)tknr.commands.at(0)->args.at(0).c_str(), nullptr};

                        if(execvp(args[0], args) < 0)
                        { // error check
                                perror("execvp");
                                exit(2);
                        }
                }
                else
                { // if parent, wait for child to finish
                        int status = 0;
                        waitpid(pid, &status, 0);
                        if(status > 1)
                        { // exit if child didn't exec properly
                                exit(status);
                        }
                }
        }
}
