//Rayaan Maredia worked on this with the use of class notes, TA hints
#include <getopt.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>
#include <string>
#include "StepList.h"

using namespace std;

StepList* recipeSteps;
vector<int>* completedSteps;
int completeCount = 0;

void PrintHelp() // Given
{

	cout << "Usage: ./MasterChef -i <file>\n\n";
	cout<<"--------------------------------------------------------------------------\n";
	cout<<"<file>:    "<<"csv file with Step, Dependencies, Time (m), Description\n";
	cout<<"--------------------------------------------------------------------------\n";
	exit(1);
}

string ProcessArgs(int argc, char** argv) // Given
{
	string result = "";
	// print help if odd number of args are provided
	if (argc < 3) {
		PrintHelp();
	}

	while (true)
	{
		const auto opt = getopt(argc, argv, "i:h");

		if (-1 == opt)
			break;

		switch (opt)
		{
		case 'i':
			result = std::string(optarg);
			break;
		case 'h': // -h or --help
		default:
			PrintHelp();
			break;
		}
	}

	return result;
}

// Creates and starts a timer given a pointer to the step to start and when it will expire in seconds.
void makeTimer( Step *timerID, int expire) // Given
{
    struct sigevent te;
    struct itimerspec its;

    /* Set and enable alarm */
    te.sigev_notify = SIGEV_SIGNAL;
    te.sigev_signo = SIGRTMIN;
    te.sigev_value.sival_ptr = timerID;
    timer_create(CLOCK_REALTIME, &te, &(timerID->t_id));

    its.it_interval.tv_sec = 0;
    its.it_interval.tv_nsec = 0;
    its.it_value.tv_sec = expire;
    its.it_value.tv_nsec = 0;
    timer_settime(timerID->t_id, 0, &its, NULL);
}

// Triggers when the time for the step has elapsed.
// the siginfo_t* pointer holds the step information in the si_value.sival_ptr
// You will need to print out that the step has completed
// Mark the step to be removed as a dependency, and trigger the remove dep handler.
// TO COMPLETE Section 2
static void timerHandler( int sig, siginfo_t *si, void *uc )
{
	(void) sig;
	(void) uc;
	// Retrieve timer pointer from the si->si_value
    Step* comp_item = (Step*)si->si_value.sival_ptr;
	
	// Hint 1: Look at how you would store the completed steps, and use that knowledge here.
	// Hint 2: Think about how you notify the user when something completes.
	// Hint 3: when something completes, dependencies change, which handler needs to be triggered to handle this?
	/* TODO This Section - 2 */

	// Officially complete the step using completedSteps and completeCount
	comp_item->PrintComplete(); //NOtify the user here
	completedSteps->push_back(comp_item->id); //store completed Step
	completeCount += 1;


	// Ready to remove that dependency, call the trigger for the appropriate handler
	kill(getpid(), SIGUSR1);
	/* End Section - 2 */
}

// Removes the copmleted steps from the dependency list of the step list.
// Utilize the completedSteps vector and the RemoveDependency method.
// To Complete - Section 3
void RemoveDepHandler(int sig) {
	/* TODO This Section - 3 */
	// Hint 1: Each completed step needs to be removed as a dependency in other steps.
	// Hint 2: Think about how you would remove an element from a list when it is no longer needed.
	// Hint 3: After processing, what happens to the list of completed steps?
	// Foreach step that has been completed since last run, remove it as a dependency
	for(int id: *completedSteps){
		recipeSteps->RemoveDependency(id);
	}
	completedSteps->clear();
	/* End Section - 3 */
}

// Associate the signals to the signal handlers as appropriate
// Continuously check what steps are ready to be run, and start timers for them with makeTimer()
// run until all steps are done.
// To Complete - Section 1
int main(int argc, char **argv)
{
	string input_file = ProcessArgs(argc, argv);
	if(input_file.empty()) {
		exit(1);
	}
	
	// Initialize global variables
	completedSteps = new vector<int>();
	recipeSteps = new StepList(input_file);

    /* Set up signal handler. */
    struct sigaction sa;
    sa.sa_flags = SA_SIGINFO;
    sa.sa_sigaction = timerHandler;
    sigemptyset(&sa.sa_mask);

	/* TODO This Section - 1 */
	// Associate the signal SIGRTMIN with the sa using the sigaction function
	// Associate the appropriate handler with the SIGUSR1 signal, for removing dependencies
	sigaction(SIGRTMIN, &sa, NULL);
	signal(SIGUSR1, RemoveDepHandler);
	/*The main
	will also continuously check if there are steps ready to be started
	and initialize timers when they are using makeTimer().*/

	// Hint 1: SIGRTMN should be handled by 'timerHandler. How do you assign this correctly using sigaction*?
	// Hint 2: What other signal might you need to handle for removing dependencies?
	// Hint 3: Think about how to keep track of the steps that are ready to be processed. How would you continuously check which
	// Hint 4: Once a step is ready to run, how do you initiate the timer for that step?
	// Hint 5; Consider the conditions to stop running the program. what needs to happen for the program to terminate
	
	
	while(completeCount < recipeSteps->Count()){
		//get steps ready to be run
		vector<Step*> ready = recipeSteps->GetReadySteps();

		for(Step* step: ready){
			//set ready states to running and start a timer
			//if(!step->running){ THIS ISN"T needed because StepList does this for us 
				makeTimer(step, step->duration);
				
				step->running = true;
				//cout <<"Started step: " << step->id << endl;USE FOR DEBUG ACTUAL TEST FAILS WITH THIS
			//}
		}
		//waits for the signal 
		pause();
		
	}
	// Until all steps have been completed, check if steps are ready to be run and create a timer for them if so
	/* End Section - 1 */

	cout << "Enjoy!" << endl;
}
